import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { code, deviceFingerprint } = await req.json()

    if (!code || !deviceFingerprint) {
      return new Response(JSON.stringify({ error: 'Code and device fingerprint required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Find the activation code
    const { data: codeData, error: codeError } = await supabase
      .from('activation_codes')
      .select('*')
      .eq('code', code.trim().toUpperCase())
      .single()

    if (codeError || !codeData) {
      return new Response(JSON.stringify({ error: 'invalid_code' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    if (!codeData.is_active) {
      return new Response(JSON.stringify({ error: 'code_disabled' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Check if this device is already activated with this code
    const { data: existingActivation } = await supabase
      .from('device_activations')
      .select('*')
      .eq('code_id', codeData.id)
      .eq('device_fingerprint', deviceFingerprint)
      .single()

    if (existingActivation) {
      return new Response(JSON.stringify({ success: true, message: 'already_activated' }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Count current activations
    const { count } = await supabase
      .from('device_activations')
      .select('*', { count: 'exact', head: true })
      .eq('code_id', codeData.id)

    if ((count ?? 0) >= codeData.max_devices) {
      return new Response(JSON.stringify({ error: 'max_devices_reached', max: codeData.max_devices }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Register this device
    const { error: insertError } = await supabase
      .from('device_activations')
      .insert({ code_id: codeData.id, device_fingerprint: deviceFingerprint })

    if (insertError) {
      return new Response(JSON.stringify({ error: 'activation_failed' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    return new Response(JSON.stringify({ success: true, message: 'activated' }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: 'server_error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
