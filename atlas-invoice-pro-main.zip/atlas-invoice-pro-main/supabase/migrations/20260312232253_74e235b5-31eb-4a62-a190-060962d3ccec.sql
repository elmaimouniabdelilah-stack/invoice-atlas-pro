
-- Table for activation codes
CREATE TABLE public.activation_codes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  max_devices INTEGER NOT NULL DEFAULT 2,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for device activations
CREATE TABLE public.device_activations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  code_id UUID NOT NULL REFERENCES public.activation_codes(id) ON DELETE CASCADE,
  device_fingerprint TEXT NOT NULL,
  activated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(code_id, device_fingerprint)
);

-- Enable RLS
ALTER TABLE public.activation_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.device_activations ENABLE ROW LEVEL SECURITY;

-- Public read-only policies (validation happens in edge function)
CREATE POLICY "Allow public select on activation_codes" ON public.activation_codes FOR SELECT USING (true);
CREATE POLICY "Allow public select on device_activations" ON public.device_activations FOR SELECT USING (true);
CREATE POLICY "Allow public insert on device_activations" ON public.device_activations FOR INSERT WITH CHECK (true);
